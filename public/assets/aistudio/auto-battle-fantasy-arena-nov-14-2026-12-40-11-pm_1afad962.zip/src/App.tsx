/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect, useState, useCallback } from 'react';
import { GameEngine } from './game/GameEngine';
import { GameState, HeroKey, PlayerStats, CombatStats, SkillDefinition, BossCategory } from './types/game';
import { HERO_DATABASE } from './game/constants';
import { sounds } from './audio/soundManager';
import { TitleScreen } from './components/TitleScreen';
import { CharacterSelectModal } from './components/CharacterSelectModal';
import { SkillSelectModal } from './components/SkillSelectModal';
import { GameHud } from './components/GameHud';
import { LevelUpModal } from './components/LevelUpModal';
import { PauseModal } from './components/PauseModal';
import { GameOverModal } from './components/GameOverModal';
import { VictoryModal } from './components/VictoryModal';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  const [gameState, setGameState] = useState<GameState>('TITLE');
  const [heroKey, setHeroKey] = useState<HeroKey>('monkey');
  const [activeSkills, setActiveSkills] = useState<SkillDefinition[]>(HERO_DATABASE.monkey.skills);

  const [playerStats, setPlayerStats] = useState<PlayerStats | null>(null);
  const [combatStats, setCombatStats] = useState<CombatStats>({
    kills: 0,
    wave: 1,
    enemiesRemaining: 0,
    timeSurvived: 0,
    damageDealt: 0,
    highestCrit: 0,
    damageTaken: 0,
    level: 1
  });
  const [activeBoss, setActiveBoss] = useState<{ name: string; hp: number; maxHp: number; category?: BossCategory; shield?: number } | null>(null);

  const [autoPilot, setAutoPilot] = useState<boolean>(true);
  const [autoCastSkills, setAutoCastSkills] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(() => sounds.getMuted());
  const [currentLevelUpLevel, setCurrentLevelUpLevel] = useState<number>(1);

  // Initialize engine once canvas mounts
  useEffect(() => {
    if (!canvasRef.current) return;
    const engine = new GameEngine(canvasRef.current, heroKey);
    engineRef.current = engine;

    // Attach callbacks
    engine.onStatsUpdate = (stats, player, boss) => {
      setCombatStats(stats);
      setPlayerStats({ ...player });
      setActiveBoss(boss);
    };

    engine.onLevelUpTrigger = (level) => {
      setCurrentLevelUpLevel(level);
      setGameState('LEVEL_UP');
    };

    engine.onGameOverTrigger = (stats) => {
      setCombatStats(stats);
      setGameState('GAME_OVER');
    };

    engine.onVictoryTrigger = (stats) => {
      setCombatStats(stats);
      setGameState('VICTORY');
    };

    const handleResize = () => {
      engine.handleResize();
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      engine.destroy();
    };
  }, []);

  // Global Keyboard shortcuts
  useEffect(() => {
    const handleGlobalKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (gameState === 'PLAYING') {
          if (engineRef.current) engineRef.current.isPaused = true;
          setGameState('PAUSED');
        } else if (gameState === 'PAUSED') {
          if (engineRef.current) engineRef.current.isPaused = false;
          setGameState('PLAYING');
        }
      } else if (e.key.toLowerCase() === 'm') {
        const nextMute = sounds.toggleMute();
        setIsMuted(nextMute);
      } else if (e.key.toLowerCase() === 'p' && gameState === 'PLAYING') {
        if (engineRef.current) {
          engineRef.current.autoPilot = !engineRef.current.autoPilot;
          setAutoPilot(engineRef.current.autoPilot);
        }
      }
    };

    window.addEventListener('keydown', handleGlobalKey);
    return () => window.removeEventListener('keydown', handleGlobalKey);
  }, [gameState]);

  // Start flow from Title -> Character Select
  const handleStartTitle = useCallback(() => {
    setGameState('CHARACTER_SELECT');
  }, []);

  // Direct hero select shortcut from title cards
  const handleSelectHeroDirect = useCallback((key: HeroKey) => {
    setHeroKey(key);
    setActiveSkills(HERO_DATABASE[key].skills);
    setGameState('SKILL_SELECT');
  }, []);

  // Character selection confirm -> Skill select
  const handleConfirmCharacter = useCallback((key: HeroKey) => {
    setHeroKey(key);
    setActiveSkills(HERO_DATABASE[key].skills);
    setGameState('SKILL_SELECT');
  }, []);

  // Skills loadout confirm -> Start Arena Battle!
  const handleConfirmSkills = useCallback((skills: SkillDefinition[]) => {
    setActiveSkills(skills);
    if (engineRef.current) {
      engineRef.current.setHero(heroKey, skills);
      engineRef.current.autoPilot = autoPilot;
      engineRef.current.autoCastSkills = autoCastSkills;
      engineRef.current.start();
    }
    setGameState('PLAYING');
  }, [heroKey, autoPilot, autoCastSkills]);

  // Level Up resolution
  const handleConfirmUpgrade = useCallback((selectedTraitId: string | null, selectedAttrId: string) => {
    if (engineRef.current) {
      if (selectedTraitId) {
        engineRef.current.applySkillUpgrade(selectedTraitId);
      }
      engineRef.current.applyAttribute(selectedAttrId);
    }
    setGameState('PLAYING');
  }, []);

  // Pause / Resume
  const handleResume = useCallback(() => {
    if (engineRef.current) engineRef.current.isPaused = false;
    setGameState('PLAYING');
  }, []);

  // Restart
  const handleRestart = useCallback(() => {
    setActiveBoss(null);
    if (engineRef.current) {
      engineRef.current.setHero(heroKey, activeSkills);
      engineRef.current.restart();
    }
    setGameState('PLAYING');
  }, [heroKey, activeSkills]);

  // Quit to Title
  const handleQuitToTitle = useCallback(() => {
    setActiveBoss(null);
    if (engineRef.current) engineRef.current.stop();
    setGameState('TITLE');
  }, []);

  // Toggles
  const handleToggleAutoPilot = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.autoPilot = !engineRef.current.autoPilot;
      setAutoPilot(engineRef.current.autoPilot);
    }
  }, []);

  const handleToggleAutoCast = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.autoCastSkills = !engineRef.current.autoCastSkills;
      setAutoCastSkills(engineRef.current.autoCastSkills);
    }
  }, []);

  const handleToggleMute = useCallback(() => {
    const next = sounds.toggleMute();
    setIsMuted(next);
  }, []);

  const handleTriggerSkill = useCallback((index: number) => {
    if (engineRef.current && playerStats) {
      if (playerStats.skillCDs[index] <= 0) {
        const target = engineRef.current.getClosestEnemy(engineRef.current.playerPos.x, engineRef.current.playerPos.y);
        engineRef.current.useSkill(index, target);
      }
    }
  }, [playerStats]);

  const currentHero = HERO_DATABASE[heroKey];

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 font-game select-none flex flex-col justify-center items-center">
      {/* 60fps Game Simulation Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full z-0 touch-none block"
      />

      {/* Title Screen View */}
      {gameState === 'TITLE' && (
        <TitleScreen
          onStart={handleStartTitle}
          onSelectHeroDirect={handleSelectHeroDirect}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* Character Selection Modal */}
      {gameState === 'CHARACTER_SELECT' && (
        <CharacterSelectModal
          onConfirmCharacter={handleConfirmCharacter}
          onBack={() => setGameState('TITLE')}
        />
      )}

      {/* Skill Loadout Selection Modal */}
      {gameState === 'SKILL_SELECT' && (
        <SkillSelectModal
          heroKey={heroKey}
          onConfirmSkills={handleConfirmSkills}
          onBack={() => setGameState('CHARACTER_SELECT')}
        />
      )}

      {/* In-Game HUD (Low-occlusion overlay) */}
      {(gameState === 'PLAYING' || gameState === 'PAUSED' || gameState === 'LEVEL_UP') && playerStats && (
        <GameHud
          player={playerStats}
          combatStats={combatStats}
          activeSkills={activeSkills}
          heroName={currentHero.name}
          heroColor={currentHero.color}
          boss={activeBoss}
          autoPilot={autoPilot}
          autoCastSkills={autoCastSkills}
          isMuted={isMuted}
          onToggleAutoPilot={handleToggleAutoPilot}
          onToggleAutoCast={handleToggleAutoCast}
          onToggleMute={handleToggleMute}
          onPause={() => {
            if (engineRef.current) engineRef.current.isPaused = true;
            setGameState('PAUSED');
          }}
          onTriggerSkill={handleTriggerSkill}
        />
      )}

      {/* Level Up Modal */}
      {gameState === 'LEVEL_UP' && (
        <LevelUpModal
          level={currentLevelUpLevel}
          heroKey={heroKey}
          activeSkillIds={activeSkills.map(s => s.id)}
          unlockedTraits={engineRef.current ? engineRef.current.unlockedTraits : new Set()}
          acquiredAttributes={engineRef.current ? engineRef.current.acquiredAttributes : new Set()}
          onConfirmUpgrade={handleConfirmUpgrade}
        />
      )}

      {/* Pause Menu Modal */}
      {gameState === 'PAUSED' && (
        <PauseModal
          onResume={handleResume}
          onRestart={handleRestart}
          onQuitToTitle={handleQuitToTitle}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* Game Over Modal */}
      {gameState === 'GAME_OVER' && (
        <GameOverModal
          stats={combatStats}
          heroName={currentHero.name}
          onRestart={handleRestart}
          onSelectHero={() => setGameState('CHARACTER_SELECT')}
        />
      )}

      {/* Victory Modal */}
      {gameState === 'VICTORY' && (
        <VictoryModal
          stats={combatStats}
          heroName={currentHero.name}
          onContinueEndless={() => {
            if (engineRef.current) engineRef.current.isPaused = false;
            setGameState('PLAYING');
          }}
          onRestart={handleRestart}
          onSelectHero={() => setGameState('CHARACTER_SELECT')}
        />
      )}
    </div>
  );
}
